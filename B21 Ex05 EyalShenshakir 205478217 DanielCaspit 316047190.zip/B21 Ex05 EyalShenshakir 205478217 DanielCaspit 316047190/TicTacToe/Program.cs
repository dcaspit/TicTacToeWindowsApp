﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace Ex05_TicTacToe_UI
{
    class Program
    {
        static void Main()
        {
            FormBegin form = new FormBegin();
            form.ShowDialog();
        }
    }

}
